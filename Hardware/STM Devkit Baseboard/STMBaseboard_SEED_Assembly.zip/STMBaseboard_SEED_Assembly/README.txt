Headers JP0, JP1, JP2, JP3 are used for connecting to an Arduino UNO as a shield.
HENCE, PLEASE DO NOT SNIP the male terminals of headers JP0, JP1, JP2, JP3.
Please refer to the attached image to see how JP0, JP1, JP2, JP3 should look.